# 晶圓電性測試：本機雙模式版本

本版僅供本機，沒有發布或修改線上版本。原模型、案例、SVG、表格、40 秒示意保留；新增 15 步／45 秒流程與同頁切換。

以任何靜態 HTTP 伺服器服務 dist/，在瀏覽器開啟；ES modules 不建議直接以 file:// 開啟。
原 dist/player.mjs 與 tests/player.test.mjs 保留供歷史對照；目前 app.mjs 改用 dual/external-player.mjs。新版播放器已另以真實瀏覽器兩種模式、五尺寸、四速度、鍵盤、進度、十輪播放及真實系統偏好驗證，見 docs/B29-local-acceptance.txt。
docs/task-v1.txt、acceptance.md 與 changes.md 是原始歷史紀錄；新的驗收結果以 B29-local-acceptance.txt 為準。
所有引用參數均為教學設定，並非實測或通用規格。
